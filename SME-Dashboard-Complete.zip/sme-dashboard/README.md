# SME Dashboard

A simple, modern **business dashboard** for small and medium enterprises (SMEs).

Track revenue, customers, products and invoices in one clean place. Built with **Next.js**, **Material UI** and **TypeScript**. Currency is set to South African Rand (R).

## Features

- **Dashboard** – overview cards (revenue, customers, products, pending invoices) + recent invoices
- **Invoices** – create, view, change status (click the chip), and delete invoices
- **Customers** – add and manage customer contact details
- **Products** – product catalogue with stock levels (low stock highlighted)
- **Settings** – basic business profile (demo)
- Responsive layout with permanent sidebar navigation
- Light professional theme

> **Note:** All data is currently stored in the browser (React state). Refreshing the page resets the lists. A real database can be added later.

## Tech Stack

- Next.js 15 (App Router)
- React 19
- Material UI (MUI) 6
- TypeScript
- Tailwind CSS (available but primarily using MUI styles)

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Run the development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### 3. Build for production

```bash
npm run build
npm start
```

## Project Structure

```
app/
  page.tsx              → Dashboard
  invoices/page.tsx     → Invoices
  customers/page.tsx    → Customers
  products/page.tsx     → Products
  settings/page.tsx     → Settings
  layout.tsx            → Root layout + theme
  ThemeRegistry.tsx     → MUI theme provider
components/
  Sidebar.tsx           → Navigation sidebar
  AppShell.tsx          → Main layout shell
```

## Next Steps (ideas for continuing)

- Connect a real database (Supabase, Firebase, or Prisma + PostgreSQL)
- Add user authentication (login / register)
- Persist invoices, customers and products
- Add charts (sales over time)
- Export invoices to PDF
- Multi-user / team support

## Deploy

The easiest way to deploy is [Vercel](https://vercel.com):

1. Push this repo to GitHub
2. Import the project in Vercel
3. Deploy

---

Built with ❤️ for small businesses.
