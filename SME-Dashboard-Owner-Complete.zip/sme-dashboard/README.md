# SME Dashboard – Owner Interface

Simple business dashboard for small and medium enterprises (South Africa).

## What works now

- **Dashboard** – overview + create invoices
- **Invoices** – create, change status, delete (data stays after refresh)
- **Customers** – add & delete (data stays)
- **Products** – add & delete, low stock highlighted (data stays)
- **Settings** – basic profile (demo)

Data is saved in the browser (localStorage). It will not disappear when you refresh.

## How to run

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Important

This is the **Owner interface** only.  
Accountant / Legal interfaces and real database / SARS / bank connections will come later.
